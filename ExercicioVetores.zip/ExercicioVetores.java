package school.sptech;

public class ExercicioVetores {
    Integer somar(Integer[] vetor){
        Integer somar = 0;

        for (int i = 0; i < vetor.length; i++) {
            somar += vetor[i];
        }
        return somar;
    }

    Double calcularMedia(Double[] notas) {
        Double media = 0.0;

        for (int i = 0; i < notas.length; i++) {
            media = media + notas[i];
        }
        return media / notas.length;
    }

    Integer buscarMaiorNumero(Integer[] vetor) {
        Integer Maiornumero = vetor[0];
        for (int i = 1; i < vetor.length; i++) {
            if (vetor[i] > Maiornumero) {
                Maiornumero = vetor[i];
            }
        }
        return Maiornumero;
    }

        Integer calcularDecimal(Integer[] binario){
            Integer decimal = 0;

            for (int i = 0; i < binario.length; i++) {
                Integer valor = binario.length - 1 - i;

                decimal = decimal + binario[i] * ((int) Math.pow(2.0, valor));
            }
            return decimal;
        }

    Character[] inverter(Character[] vetor) {
        Character[] invertido = new Character[vetor.length];

        for (int i = 0; i < vetor.length; i++) {
            invertido[i] = vetor[vetor.length - 1 - i];
        }
        return invertido;
    }

    Integer[] somarDois(Integer[] vetor, Integer alvo) {

        for (int i = 0; i < vetor.length; i++) {
            for (int j = i + 1; j < vetor.length; j++) {
                if (vetor[i] + vetor[j] == alvo) {
                    return new Integer[]{i, j};
                }
            }
        }
        return new Integer[]{};
    }
    }



